import 'package:flutter/material.dart';
import '../../constants.dart';
import '../../models/models.dart';
import '../../services/api_service.dart';
import '../../widgets/widgets.dart';

// ══════════════════════════════════════════════════════════════
// ÉDITION — MATIÈRES PAR FILIÈRE
// ══════════════════════════════════════════════════════════════
class EditionFiliereScreen extends StatefulWidget {
  const EditionFiliereScreen({super.key});
  @override State<EditionFiliereScreen> createState() => _EditionFiliereScreenState();
}

class _EditionFiliereScreenState extends State<EditionFiliereScreen> {
  List<Filiere> _filieres = [];
  List<Periode> _periodes = [];
  List<Matiere> _matieres = [];
  Filiere? _filiere;
  Periode? _periode;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    Future.wait([ApiService.getFilieres(), ApiService.getPeriodes()]).then((r) {
      setState(() { _filieres = r[0] as List<Filiere>; _periodes = r[1] as List<Periode>; });
    });
  }

  Future<void> _load() async {
    if (_filiere == null) return;
    setState(() => _loading = true);
    try {
      final m = await ApiService.getMatieres(filiereId: _filiere!.id);
      setState(() { _matieres = m; _loading = false; });
    } catch (e) { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) => LoadingOverlay(
    isLoading: _loading,
    child: Scaffold(
      backgroundColor: AppConstants.background,
      body: Column(children: [
        Container(
          color: AppConstants.surface, padding: const EdgeInsets.all(12),
          child: Row(children: [
            Expanded(child: DropdownButtonFormField<Filiere>(
              value: _filiere, isDense: true,
              decoration: const InputDecoration(labelText: 'Filière'),
              items: _filieres.map((f) => DropdownMenuItem(value: f, child: Text(f.libelleFiliere, overflow: TextOverflow.ellipsis))).toList(),
              onChanged: (v) { setState(() { _filiere = v; _matieres = []; }); _load(); },
            )),
            const SizedBox(width: 8),
            Expanded(child: DropdownButtonFormField<Periode>(
              value: _periode, isDense: true,
              decoration: const InputDecoration(labelText: 'Période'),
              items: _periodes.map((p) => DropdownMenuItem(value: p, child: Text(p.idPeriode))).toList(),
              onChanged: (v) => setState(() => _periode = v),
            )),
          ]),
        ),
        Expanded(
          child: _matieres.isEmpty
              ? const EmptyState(message: 'Sélectionnez une filière', icon: Icons.table_chart_outlined)
              : ListView.separated(
                  padding: const EdgeInsets.all(16), itemCount: _matieres.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    final m = _matieres[i];
                    return AppCard(child: Row(children: [
                      Container(
                        width: 42, height: 42,
                        decoration: BoxDecoration(color: AppConstants.successBg, borderRadius: BorderRadius.circular(8)),
                        child: Center(child: Text(m.codeMatiere.substring(0, 3),
                            style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppConstants.success))),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(m.nomMatiere, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                        Text('${m.codeMatiere} · ${m.volumeHoraire}h',
                            style: const TextStyle(fontSize: 11, color: AppConstants.secondary)),
                      ])),
                    ]));
                  },
                ),
        ),
      ]),
    ),
  );
}

// ══════════════════════════════════════════════════════════════
// ÉDITION — ABSENCES PAR FILIÈRE & PÉRIODE
// ══════════════════════════════════════════════════════════════
class EditionAbsenceScreen extends StatefulWidget {
  const EditionAbsenceScreen({super.key});
  @override State<EditionAbsenceScreen> createState() => _EditionAbsenceScreenState();
}

class _EditionAbsenceScreenState extends State<EditionAbsenceScreen> {
  List<Filiere> _filieres = [];
  List<Periode> _periodes = [];
  Filiere? _filiere;
  Periode? _periode;
  List<Map<String, dynamic>> _rapport = [];
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    Future.wait([ApiService.getFilieres(), ApiService.getPeriodes()]).then((r) {
      setState(() { _filieres = r[0] as List<Filiere>; _periodes = r[1] as List<Periode>; });
    });
  }

  Future<void> _generer() async {
    if (_filiere == null) { showSnack(context, 'Sélectionnez une filière', error: true); return; }
    setState(() => _loading = true);
    try {
      final r = await ApiService.getRapportFiliere(_filiere!.id!, periodeId: _periode?.id);
      setState(() { _rapport = List<Map<String, dynamic>>.from(r['data'] ?? []); _loading = false; });
    } catch (e) { setState(() => _loading = false); showSnack(context, 'Erreur: $e', error: true); }
  }

  int get _total => _rapport.fold(0, (s, r) => s + ((r['total_absences'] ?? 0) as int));
  int get _justif => _rapport.fold(0, (s, r) => s + ((r['justifiees'] ?? 0) as int));
  int get _nonJustif => _rapport.fold(0, (s, r) => s + ((r['non_justifiees'] ?? 0) as int));

  @override
  Widget build(BuildContext context) => LoadingOverlay(
    isLoading: _loading,
    child: Scaffold(
      backgroundColor: AppConstants.background,
      body: Column(children: [
        Container(
          color: AppConstants.surface, padding: const EdgeInsets.all(12),
          child: Column(children: [
            Row(children: [
              Expanded(child: DropdownButtonFormField<Filiere>(
                value: _filiere, isDense: true,
                decoration: const InputDecoration(labelText: 'Filière'),
                items: _filieres.map((f) => DropdownMenuItem(value: f, child: Text(f.libelleFiliere, overflow: TextOverflow.ellipsis))).toList(),
                onChanged: (v) => setState(() => _filiere = v),
              )),
              const SizedBox(width: 8),
              Expanded(child: DropdownButtonFormField<Periode>(
                value: _periode, isDense: true,
                decoration: const InputDecoration(labelText: 'Période'),
                items: [
                  const DropdownMenuItem(value: null, child: Text('Toutes')),
                  ..._periodes.map((p) => DropdownMenuItem(value: p, child: Text(p.idPeriode))),
                ],
                onChanged: (v) => setState(() => _periode = v),
              )),
            ]),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity,
                child: ElevatedButton(onPressed: _generer, child: const Text('Générer le rapport'))),
          ]),
        ),
        if (_rapport.isNotEmpty) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Row(children: [
              Expanded(child: MetricCard(label: 'Total', value: '$_total')),
              const SizedBox(width: 8),
              Expanded(child: MetricCard(label: 'Justifiées', value: '$_justif', valueColor: AppConstants.success)),
              const SizedBox(width: 8),
              Expanded(child: MetricCard(label: 'Non justif.', value: '$_nonJustif', valueColor: AppConstants.danger)),
            ]),
          ),
        ],
        Expanded(
          child: _rapport.isEmpty
              ? const EmptyState(message: 'Sélectionnez les filtres et générez', icon: Icons.analytics_outlined)
              : ListView.separated(
                  padding: const EdgeInsets.all(16), itemCount: _rapport.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    final r = _rapport[i];
                    final total = (r['total_absences'] ?? 0) as int;
                    final j = (r['justifiees'] ?? 0) as int;
                    final nj = (r['non_justifiees'] ?? 0) as int;
                    return AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(r['nom_matiere'] ?? '', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                      Text(r['code_matiere'] ?? '', style: const TextStyle(fontSize: 10, color: AppConstants.secondary)),
                      const SizedBox(height: 10),
                      Row(children: [
                        _chip('Total: $total', AppConstants.info, AppConstants.infoBg),
                        const SizedBox(width: 6),
                        _chip('✓ $j', AppConstants.success, AppConstants.successBg),
                        const SizedBox(width: 6),
                        _chip('✗ $nj', AppConstants.danger, AppConstants.dangerBg),
                      ]),
                    ]));
                  },
                ),
        ),
      ]),
    ),
  );

  Widget _chip(String lbl, Color fg, Color bg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(6)),
    child: Text(lbl, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: fg)),
  );
}

// ══════════════════════════════════════════════════════════════
// ÉDITION — PAR ÉTUDIANT
// ══════════════════════════════════════════════════════════════
class EditionEtudiantScreen extends StatefulWidget {
  const EditionEtudiantScreen({super.key});
  @override State<EditionEtudiantScreen> createState() => _EditionEtudiantScreenState();
}

class _EditionEtudiantScreenState extends State<EditionEtudiantScreen> {
  List<Etudiant> _etudiants = [];
  List<Periode> _periodes = [];
  Etudiant? _etudiant;
  Periode? _periode;
  List<Presence> _absences = [];
  Map<String, dynamic>? _stats;
  bool _loading = false;
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    Future.wait([ApiService.getEtudiants(), ApiService.getPeriodes()]).then((r) {
      setState(() { _etudiants = r[0] as List<Etudiant>; _periodes = r[1] as List<Periode>; });
    });
  }

  List<Etudiant> get _filtered {
    final q = _searchCtrl.text.toLowerCase();
    if (q.isEmpty) return _etudiants;
    return _etudiants.where((e) =>
        e.nomComplet.toLowerCase().contains(q) ||
        e.numeroEtudiant.toLowerCase().contains(q)).toList();
  }

  Future<void> _generer() async {
    if (_etudiant == null) { showSnack(context, 'Sélectionnez un étudiant', error: true); return; }
    setState(() => _loading = true);
    try {
      final r = await ApiService.getRapportEtudiant(_etudiant!.id!, periodeId: _periode?.id);
      final data = r['data'];
      setState(() {
        _absences = (data['absences'] as List).map((a) => Presence.fromJson(a)).toList();
        _stats = data['stats'];
        _loading = false;
      });
    } catch (e) { setState(() => _loading = false); showSnack(context, 'Erreur: $e', error: true); }
  }

  @override
  Widget build(BuildContext context) => LoadingOverlay(
    isLoading: _loading,
    child: Scaffold(
      backgroundColor: AppConstants.background,
      body: Column(children: [
        Container(
          color: AppConstants.surface, padding: const EdgeInsets.all(12),
          child: Column(children: [
            TextField(
              controller: _searchCtrl, onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                labelText: 'Rechercher un étudiant', isDense: true,
                prefixIcon: Icon(Icons.search, size: 18),
              ),
            ),
            if (_searchCtrl.text.isNotEmpty && _etudiant == null) ...[
              const SizedBox(height: 6),
              Container(
                constraints: const BoxConstraints(maxHeight: 150),
                decoration: BoxDecoration(
                  color: AppConstants.surface,
                  border: Border.all(color: AppConstants.border),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ListView(shrinkWrap: true, children: _filtered.take(5).map((e) =>
                  ListTile(dense: true,
                    title: Text(e.nomComplet, style: const TextStyle(fontSize: 13)),
                    subtitle: Text(e.numeroEtudiant, style: const TextStyle(fontSize: 10)),
                    onTap: () { setState(() { _etudiant = e; _searchCtrl.text = e.nomComplet; }); },
                  ),
                ).toList()),
              ),
            ],
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: DropdownButtonFormField<Periode>(
                value: _periode, isDense: true,
                decoration: const InputDecoration(labelText: 'Période'),
                items: [
                  const DropdownMenuItem(value: null, child: Text('Toutes')),
                  ..._periodes.map((p) => DropdownMenuItem(value: p, child: Text(p.idPeriode))),
                ],
                onChanged: (v) => setState(() => _periode = v),
              )),
              const SizedBox(width: 8),
              ElevatedButton(onPressed: _generer, child: const Text('Générer')),
            ]),
          ]),
        ),
        if (_etudiant != null && _stats != null) ...[
          Padding(
            padding: const EdgeInsets.all(16),
            child: AppCard(child: Row(children: [
              InitialesAvatar(initiales: _etudiant!.initiales, size: 48),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_etudiant!.nomComplet,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                Text('${_etudiant!.numeroEtudiant} · ${_etudiant!.libelleFiliere ?? ''}',
                    style: const TextStyle(fontSize: 11, color: AppConstants.secondary)),
              ])),
              Column(children: [
                Text('${_stats!['total'] ?? 0}',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: AppConstants.danger)),
                const Text('absences', style: TextStyle(fontSize: 9, color: AppConstants.secondary)),
              ]),
              const SizedBox(width: 16),
              Column(children: [
                Text('${_stats!['justifiees'] ?? 0}',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: AppConstants.success)),
                const Text('justifiées', style: TextStyle(fontSize: 9, color: AppConstants.secondary)),
              ]),
            ])),
          ),
        ],
        Expanded(
          child: _absences.isEmpty
              ? const EmptyState(message: 'Aucune absence pour cet étudiant', icon: Icons.check_circle_outline)
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  itemCount: _absences.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    final a = _absences[i];
                    return AppCard(child: Row(children: [
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(a.nomMatiere ?? '', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                        Text(a.dateEnseignement ?? '', style: const TextStyle(fontSize: 11, color: AppConstants.secondary)),
                        if (a.motif != null)
                          Text('Motif: ${a.motif}', style: const TextStyle(fontSize: 10, color: AppConstants.secondary)),
                      ])),
                      StatusBadge(
                        label: a.statut == 'justifie' ? 'Justifiée' : 'Non justifiée',
                        type: a.statut == 'justifie' ? 'success' : 'danger',
                      ),
                    ]));
                  },
                ),
        ),
      ]),
    ),
  );
}
